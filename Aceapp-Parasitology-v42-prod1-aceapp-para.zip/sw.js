const VERSION='aceapp-para-v42-prod1';
const SHELL=`${VERSION}-shell`;
const RUNTIME=`${VERSION}-runtime`;
const REFERENCE=`${VERSION}-reference`;
const OFFLINE_PACK=`${VERSION}-offline-pack`;
const PRECACHE=[
  './',
  './index.html',
  './manifest.webmanifest',
  './release-manifest-v42-prod1.json',
  './aceapp_asset_integrity_manifest_v42-prod1.json',
  './icons/aceapp-192.png',
  './icons/aceapp-512.png'
];

self.addEventListener('install',event=>{
  event.waitUntil(caches.open(SHELL).then(cache=>cache.addAll(PRECACHE)));
});

self.addEventListener('activate',event=>{
  event.waitUntil(
    caches.keys().then(keys=>Promise.all(keys.filter(k=>!k.startsWith(VERSION)).map(k=>caches.delete(k))))
      .then(()=>self.clients.claim())
  );
});

async function offlinePackMatch(request){
  try{
    const cache=await caches.open(OFFLINE_PACK);
    return await cache.match(request,{ignoreVary:true});
  }catch{return null;}
}

async function networkFirst(request){
  const cache=await caches.open(RUNTIME);
  try{
    const response=await fetch(request);
    if(response && (response.ok || response.type==='opaque')) cache.put(request,response.clone()).catch(()=>{});
    return response;
  }catch(err){
    const cached=(await cache.match(request)) || (await offlinePackMatch(request));
    if(cached) return cached;
    if(request.mode==='navigate') return (await caches.open(SHELL)).match('./index.html');
    throw err;
  }
}

async function staleWhileRevalidate(request,cacheName=RUNTIME){
  const cache=await caches.open(cacheName);
  const cached=(await cache.match(request)) || (await offlinePackMatch(request));
  const update=fetch(request).then(response=>{
    if(response && (response.ok || response.type==='opaque')) cache.put(request,response.clone()).catch(()=>{});
    return response;
  }).catch(()=>null);
  return cached || (await update) || Response.error();
}

self.addEventListener('message',event=>{
  if(event.data && event.data.type==='SKIP_WAITING'){
    self.skipWaiting();
    return;
  }
  if(event.data && event.data.type==='GET_VERSION'){
    const port=event.ports && event.ports[0];
    if(port) port.postMessage({type:'ACE_VERSION',version:VERSION});
  }
});

self.addEventListener('fetch',event=>{
  const request=event.request;
  if(request.method!=='GET') return;
  const url=new URL(request.url);

  if(request.mode==='navigate'){
    event.respondWith(networkFirst(request));
    return;
  }

  if(url.origin===self.location.origin){
    event.respondWith(staleWhileRevalidate(request,RUNTIME));
    return;
  }

  if(url.hostname==='www.cdc.gov'){
    event.respondWith(staleWhileRevalidate(request,REFERENCE));
    return;
  }

  if(
    url.hostname.endsWith('gstatic.com') ||
    url.hostname.endsWith('googleapis.com') ||
    url.hostname==='esm.sh' ||
    url.hostname==='cdn.jsdelivr.net' ||
    url.hostname==='unpkg.com'
  ){
    event.respondWith(staleWhileRevalidate(request,RUNTIME));
  }
});
