import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
const root=process.argv[2]||'.';
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const rules=fs.readFileSync(path.join(root,'firebase','firestore.rules'),'utf8');
const sw=fs.readFileSync(path.join(root,'sw.js'),'utf8');
const release=JSON.parse(fs.readFileSync(path.join(root,'release-manifest-v42.json'),'utf8'));
const bad=[];
for(const [rel,meta] of Object.entries(release.files)){
  const p=path.join(root,rel);
  if(!fs.existsSync(p)){bad.push(rel+':missing');continue;}
  const h=crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
  if(h!==meta.sha256)bad.push(rel+':hash');
}
const install=(sw.match(/self\.addEventListener\('install',event=>\{([\s\S]*?)\n\}\);/)||[])[1]||'';
const collector=html.slice(html.indexOf('async function collectOwnPrivacyRefs'),html.indexOf('function cancelPendingCloudWrites'));
const checks=[
 ['v42',html.includes("ACEAPP_BUILD='v42-rc1'")],
 ['privacy center',html.includes("screen==='privacy-center'")],
 ['privacy export',html.includes('exportPrivacyArchive')],
 ['device-only clear',html.includes('clearDeviceAndSignOut')],
 ['study reset',html.includes('resetStudyProgressEverywhere')],
 ['account deletion',html.includes('deleteAceappAccount')],
 ['reauth required',html.includes('reauthenticateWithCredential')],
 ['admin delete blocked',html.includes('Admin accounts cannot be deleted from the learner client.')],
 ['owner data collector excludes assetOverrides',!collector.includes('FIREBASE_ASSET_OVERRIDES')],
 ['owner data collector excludes assetRevisions',!collector.includes('FIREBASE_ASSET_REVISIONS')],
 ['owner data collector excludes synthetic overrides',!collector.includes('FIREBASE_SYNTHETIC_OVERRIDES')],
 ['privacy flag rules',rules.includes('privacyDeletionPending')&&rules.includes('privacyDeletionActive(uid)')],
 ['progress delete gated',rules.includes('allow delete: if privacyDeletionActive(uid);')],
 ['admin role protected',rules.includes("data.get('role', '') != 'admin'")],
 ['release hashes',bad.length===0],
 ['controlled worker update',!install.includes('skipWaiting')&&sw.includes("type==='SKIP_WAITING'")],
 ['compatibility safety retained',html.includes('detectCloudCompatibility')],
 ['crash recovery retained',html.includes('aceapp.parasitology.bootHealth.v1')],
 ['Sync Center retained',html.includes("screen==='sync-center'")],
 ['exam integrity retained',html.includes('aVariants>=2 && bVariants>=2')],
 ['hard-disable retained',html.includes('if (!approved.length) return [];')]
];
let fail=0;
for(const [label,ok] of checks){console.log(`${ok?'PASS':'FAIL'}  ${label}`);if(!ok)fail++;}
if(bad.length)console.log('Bad release files:',bad);
console.log(`\n${checks.length-fail}/${checks.length} checks passed`);
process.exitCode=fail?1:0;
